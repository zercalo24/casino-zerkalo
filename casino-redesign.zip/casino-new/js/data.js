/* ══════════════════════════════════════════════════════
   CasinoTop — Casino Data
   Update this file to add/edit casinos.
   Icons: place your .webp files in assets/icons/<key>.webp
   ══════════════════════════════════════════════════════ */

const ICONS_PATH = 'assets/icons/';

/**
 * Helper — returns the icon URL for a given casino key.
 * Falls back to an empty string if the icon doesn't exist.
 */
function iconUrl(key) {
  return ICONS_PATH + key + '.webp';
}

/**
 * Casino data array.
 * Fields:
 *   id          — unique number
 *   key         — icon filename without extension (assets/icons/<key>.webp)
 *   name        — display name
 *   url         — affiliate link (rel="sponsored" applied in app.js)
 *   rating      — 0–5 (one decimal)
 *   license     — 'MGA' | 'UKGC' | 'Curacao'
 *   minDeposit  — number in ₽
 *   bonusText   — human-readable bonus string
 *   bonusAmount — numeric amount for sorting
 *   bonusTypes  — array of: 'match' | 'freespins' | 'nodeposit'
 *   wagering    — e.g. 'x40'
 *   withdrawSpeed — 'до 24ч' | '1–3 дня'
 *   withdrawLimit — string
 *   verified    — boolean (green badge + verified section)
 *   isNew       — boolean (gold NEW badge)
 *   providers   — array of provider names
 *   support     — string describing support channels
 *   pros        — array of strings
 *   cons        — array of strings
 */
const casinos = [
  {
    "id": 1,
    "key": "kush",
    "name": "Куш Казино",
    "url": "https://pl4y-zn-ksh.com/dsctkbuvt",
    "rating": 4.8,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 50 000 ₽ + 200 FS",
    "bonusAmount": 50000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "30 000 ₽/день",
    "verified": true,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Microgaming",
      "Evolution",
      "Play'n GO",
      "Amatic"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Щедрый приветственный пакет",
      "200 фриспинов при регистрации",
      "Быстрые выплаты до 24 ч",
      "Мобильная версия"
    ],
    "cons": [
      "Вейджер x40 — выше среднего",
      "Нет телефонной поддержки"
    ]
  },
  {
    "id": 2,
    "key": "leebet",
    "name": "LeeBet",
    "url": "https://play-leebet-4th.com/dakw9czmc",
    "rating": 4.7,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "150% до 75 000 ₽ + 100 FS",
    "bonusAmount": 75000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x35",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "50 000 ₽/день",
    "verified": true,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "Push Gaming",
      "Nolimit City",
      "Relax Gaming",
      "BGaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Telegram",
    "pros": [
      "150% бонус — щедрее среднего",
      "Быстрые выплаты",
      "Telegram-поддержка",
      "Большой лимит вывода"
    ],
    "cons": [
      "Лицензия Curacao (не MGA/UKGC)",
      "Ограниченный выбор live-игр"
    ]
  },
  {
    "id": 3,
    "key": "banda",
    "name": "Banda Casino",
    "url": "https://play-b4nd-zn-light.com/d8opvl4oe",
    "rating": 4.6,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + 50 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x30",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "25 000 ₽/день",
    "verified": true,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Play'n GO",
      "Microgaming",
      "Quickspin",
      "Yggdrasil"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Низкий вейджер x30",
      "Быстрые выплаты",
      "Отличный дизайн",
      "Удобный поиск слотов"
    ],
    "cons": [
      "Средний размер бонуса",
      "Нет программы лояльности"
    ]
  },
  {
    "id": 4,
    "key": "1go",
    "name": "1GO Casino",
    "url": "https://luckyspin23.com/ce3ee979d",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 50,
    "bonusText": "200% до 20 000 ₽ + 77 FS",
    "bonusAmount": 20000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x45",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Endorphina",
      "BGaming",
      "Amatic",
      "Igrosoft",
      "Playson"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "200% бонус на первый депозит",
      "77 фриспинов",
      "Мин. депозит от 50 ₽",
      "Crypto-платежи"
    ],
    "cons": [
      "Высокий вейджер x45",
      "Вывод 1–3 дня"
    ]
  },
  {
    "id": 5,
    "key": "martin",
    "name": "Martin Casino",
    "url": "https://luckyspin23.com/cf930f628",
    "rating": 4.3,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 15 000 ₽ + 30 FS",
    "bonusAmount": 15000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "15 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Play'n GO",
      "NetEnt",
      "Microgaming",
      "Evolution"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Стабильная работа без сбоев",
      "Честный рандом",
      "Хорошая поддержка"
    ],
    "cons": [
      "Небольшой бонус",
      "Вывод 1–3 дня",
      "Лимит вывода невысокий"
    ]
  },
  {
    "id": 6,
    "key": "flagman",
    "name": "Flagman Casino",
    "url": "https://luckyspin23.com/c53208e7a",
    "rating": 4.4,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 25 000 ₽ + 100 FS",
    "bonusAmount": 25000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x38",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Evolution",
      "Play'n GO",
      "Novomatic",
      "Quickspin"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "100 фриспинов",
      "Быстрые выплаты до 24 ч",
      "Большой выбор провайдеров"
    ],
    "cons": [
      "Вейджер x38",
      "Нет бездепозитного бонуса"
    ]
  },
  {
    "id": 7,
    "key": "volna",
    "name": "Volna Casino",
    "url": "https://luckyspin23.com/c0b60ebdc",
    "rating": 4.2,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 20 000 ₽ + 50 FS",
    "bonusAmount": 20000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "15 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "BGaming",
      "Amatic",
      "Endorphina",
      "Playson"
    ],
    "support": "Онлайн-чат, Email",
    "pros": [
      "Простая регистрация",
      "Широкий выбор слотов",
      "Crypto-платежи"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Ограниченная поддержка",
      "Вейджер x40"
    ]
  },
  {
    "id": 8,
    "key": "beef",
    "name": "Beef Casino",
    "url": "https://luckyspin23.com/c2197b5c3",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + ежедневный кэшбэк",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match"
    ],
    "wagering": "x35",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "25 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Play'n GO",
      "Evolution",
      "NetEnt",
      "BGaming",
      "Booming Games"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Ежедневный рейкбэк",
      "Вейджер x35",
      "Быстрые выплаты",
      "Кэшбэк каждый день"
    ],
    "cons": [
      "Нет фриспинов в бонусе",
      "Ограниченный лимит вывода"
    ]
  },
  {
    "id": 9,
    "key": "starda",
    "name": "Starda Casino",
    "url": "https://luckyspin23.com/c2f2d2001",
    "rating": 4.6,
    "license": "Curacao",
    "minDeposit": 50,
    "bonusText": "100% до 30 000 ₽ + 200 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "30 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Play'n GO",
      "Evolution",
      "Quickspin",
      "Thunderkick"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "200 фриспинов при регистрации",
      "Быстрые выплаты",
      "Мин. депозит от 50 ₽",
      "Стильный интерфейс"
    ],
    "cons": [
      "Вейджер x40",
      "Нет телефонной поддержки"
    ]
  },
  {
    "id": 10,
    "key": "gizbo",
    "name": "Gizbo Casino",
    "url": "https://luckyspin23.com/c95b15693",
    "rating": 4.3,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "150% до 20 000 ₽ + 50 FS",
    "bonusAmount": 20000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "BGaming",
      "Amatic",
      "Microgaming",
      "Playson"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "150% на первый депозит",
      "Большой выбор слотов",
      "Удобный интерфейс"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Вейджер x40"
    ]
  },
  {
    "id": 11,
    "key": "rox",
    "name": "ROX Casino",
    "url": "https://luckyspin23.com/c539c0617",
    "rating": 4.7,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "200% до 100 000 ₽ + 200 FS",
    "bonusAmount": 100000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "50 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Play'n GO",
      "Evolution",
      "Nolimit City",
      "Push Gaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Telegram",
    "pros": [
      "Огромный бонус до 100 000 ₽",
      "200 фриспинов",
      "Кэшбэк 10%",
      "Программа лояльности"
    ],
    "cons": [
      "Вейджер x40",
      "Нужна верификация для вывода"
    ]
  },
  {
    "id": 12,
    "key": "monro",
    "name": "Monro Casino",
    "url": "https://luckyspin23.com/c6f3677f9",
    "rating": 4.4,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + 150 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "NetEnt",
      "Microgaming",
      "Playson"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "150 фриспинов",
      "Быстрые выплаты",
      "Хорошая поддержка"
    ],
    "cons": [
      "Средний лимит вывода",
      "Вейджер x40"
    ]
  },
  {
    "id": 13,
    "key": "sol",
    "name": "Sol Casino",
    "url": "https://luckyspin23.com/c6c6e3028",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 40 000 ₽ + 100 FS",
    "bonusAmount": 40000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "30 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "BGaming",
      "Amatic",
      "Evolution",
      "Igrosoft",
      "Quickspin"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Хороший ассортимент слотов",
      "Быстрые выплаты",
      "Удобный мобильный интерфейс"
    ],
    "cons": [
      "Вейджер x40",
      "Без бездепозитного бонуса"
    ]
  },
  {
    "id": 14,
    "key": "drip",
    "name": "Drip Casino",
    "url": "https://luckyspin23.com/c2aa637a4",
    "rating": 4.3,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 25 000 ₽ + 75 FS",
    "bonusAmount": 25000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x38",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Play'n GO",
      "NetEnt",
      "BGaming",
      "Amatic"
    ],
    "support": "Онлайн-чат, Email",
    "pros": [
      "75 фриспинов",
      "Вейджер x38 — ниже среднего",
      "Crypto-платежи"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Ограниченная поддержка"
    ]
  },
  {
    "id": 15,
    "key": "izzi",
    "name": "IZZI Casino",
    "url": "https://luckyspin23.com/c43f751ad",
    "rating": 4.6,
    "license": "Curacao",
    "minDeposit": 50,
    "bonusText": "100% до 50 000 ₽ + 100 FS",
    "bonusAmount": 50000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x35",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "40 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "Nolimit City",
      "Push Gaming",
      "Relax Gaming",
      "BGaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Telegram",
    "pros": [
      "Вейджер x35 — приемлемый",
      "100 фриспинов",
      "Telegram-поддержка",
      "Мин. депозит от 50 ₽"
    ],
    "cons": [
      "Лицензия Curacao",
      "Нет телефонной поддержки"
    ]
  },
  {
    "id": 16,
    "key": "fresh",
    "name": "Fresh Casino",
    "url": "https://luckyspin23.com/c68dac41e",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + 200 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "30 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Play'n GO",
      "Microgaming",
      "Evolution",
      "Yggdrasil"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "200 фриспинов",
      "Быстрые выплаты",
      "Большой ассортимент игр",
      "Бонусы каждую неделю"
    ],
    "cons": [
      "Вейджер x40",
      "Нет Crypto-платежей"
    ]
  },
  {
    "id": 17,
    "key": "lexx",
    "name": "Lexx Casino",
    "url": "https://luckyspin23.com/c6a279922",
    "rating": 4.2,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 20 000 ₽ + 50 FS",
    "bonusAmount": 20000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "15 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "BGaming",
      "Amatic",
      "Playson",
      "Endorphina"
    ],
    "support": "Онлайн-чат, Email",
    "pros": [
      "Простой интерфейс",
      "Широкий выбор слотов",
      "Crypto-платежи"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Небольшой лимит",
      "Вейджер x40"
    ]
  },
  {
    "id": 18,
    "key": "fugu",
    "name": "Fugu Casino",
    "url": "https://luckyspin23.com/cf06cace2",
    "rating": 4.4,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 25 000 ₽ + 50 FS",
    "bonusAmount": 25000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x35",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": true,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "Play'n GO",
      "Quickspin",
      "Thunderkick"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "Японская тематика — уникальный дизайн",
      "Вейджер x35",
      "Быстрые выплаты",
      "Новинка с эксклюзивными слотами"
    ],
    "cons": [
      "Новое казино — меньше отзывов",
      "Ограниченный лимит"
    ]
  },
  {
    "id": 19,
    "key": "daddy",
    "name": "Daddy Casino",
    "url": "https://eclipse-propel.com/sjw6v0biu",
    "rating": 4.8,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 100 000 ₽ + 250 FS",
    "bonusAmount": 100000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "50 000 ₽/день",
    "verified": true,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "Nolimit City",
      "Push Gaming",
      "Play'n GO",
      "NetEnt",
      "Relax Gaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Telegram",
    "pros": [
      "Огромный бонус до 100 000 ₽",
      "250 фриспинов",
      "Кэшбэк 15%",
      "Быстрые выплаты",
      "Программа лояльности"
    ],
    "cons": [
      "Вейджер x40",
      "Нужна верификация"
    ]
  },
  {
    "id": 20,
    "key": "arkada",
    "name": "Arkada Casino",
    "url": "https://orbit-burn.com/sjyfpt9lu",
    "rating": 4.6,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "150% до 75 000 ₽ + 100 FS",
    "bonusAmount": 75000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x35",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "40 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "NetEnt",
      "BGaming",
      "Evolution",
      "Amatic",
      "Igrosoft"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "150% на первый депозит",
      "Вейджер x35",
      "Быстрые выплаты",
      "Хороший ассортимент"
    ],
    "cons": [
      "Лицензия Curacao",
      "Нет мобильного приложения"
    ]
  },
  {
    "id": 21,
    "key": "gama",
    "name": "Gama Casino",
    "url": "https://starforge-race.com/s8xcfzhvw",
    "rating": 4.7,
    "license": "Curacao",
    "minDeposit": 50,
    "bonusText": "100% до 50 000 ₽ + 150 FS",
    "bonusAmount": 50000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "35 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "Play'n GO",
      "Nolimit City",
      "Push Gaming",
      "BGaming"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "150 фриспинов",
      "Мин. депозит от 50 ₽",
      "Быстрые выплаты",
      "Турниры и акции"
    ],
    "cons": [
      "Вейджер x40",
      "Без программы лояльности"
    ]
  },
  {
    "id": 22,
    "key": "kent",
    "name": "Kent Casino",
    "url": "https://cosmic-kinetics.com/sroosyate",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "VIP Welcome Pack — реальные подарки",
    "bonusAmount": 50000,
    "bonusTypes": [
      "match"
    ],
    "wagering": "x35",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "40 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "NetEnt",
      "Microgaming",
      "Playtech",
      "Red Tiger"
    ],
    "support": "Онлайн-чат 24/7, Email, VIP-менеджер",
    "pros": [
      "VIP-программа с реальными подарками",
      "Личный менеджер",
      "Вейджер x35",
      "Лимит вывода 40 000 ₽"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Условия VIP непрозрачны"
    ]
  },
  {
    "id": 23,
    "key": "cat",
    "name": "Cat Casino",
    "url": "https://cosmic-propel.com/s8xpflrrv",
    "rating": 4.8,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "200% до 100 000 ₽ + кэшбэк 15%",
    "bonusAmount": 100000,
    "bonusTypes": [
      "match"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "50 000 ₽/день",
    "verified": true,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Evolution",
      "NetEnt",
      "Play'n GO",
      "Nolimit City",
      "Relax Gaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Telegram",
    "pros": [
      "200% бонус — максимум на рынке",
      "Кэшбэк 15%",
      "Быстрые выплаты",
      "Отличная поддержка"
    ],
    "cons": [
      "Вейджер x40",
      "Нужна верификация при крупном выводе"
    ]
  },
  {
    "id": 24,
    "key": "r7",
    "name": "R7 Casino",
    "url": "https://hyper-trail.com/slc53vzfn",
    "rating": 4.4,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + 70 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "25 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "BGaming",
      "Amatic",
      "NetEnt",
      "Igrosoft",
      "Microgaming"
    ],
    "support": "Онлайн-чат 24/7, Email",
    "pros": [
      "70 фриспинов",
      "Быстрые выплаты",
      "Большой выбор слотов",
      "Удобный поиск"
    ],
    "cons": [
      "Вейджер x40",
      "Скромный дизайн"
    ]
  },
  {
    "id": 25,
    "key": "kometa",
    "name": "Kometa Casino",
    "url": "https://eclipse-vectorial.com/sgztgjshb",
    "rating": 4.3,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 20 000 ₽ + 50 FS",
    "bonusAmount": 20000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "1–3 дня",
    "withdrawLimit": "20 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Play'n GO",
      "BGaming",
      "Endorphina",
      "Amatic"
    ],
    "support": "Онлайн-чат, Email",
    "pros": [
      "50 фриспинов",
      "Широкий выбор слотов",
      "Crypto-платежи"
    ],
    "cons": [
      "Вывод 1–3 дня",
      "Ограниченная поддержка",
      "Вейджер x40"
    ]
  },
  {
    "id": 26,
    "key": "champion",
    "name": "Чемпион Слотс",
    "url": "https://cass-championslots.bet/go/mKq?p75341p311673pe420",
    "rating": 4.5,
    "license": "Curacao",
    "minDeposit": 100,
    "bonusText": "100% до 30 000 ₽ + 100 FS",
    "bonusAmount": 30000,
    "bonusTypes": [
      "match",
      "freespins"
    ],
    "wagering": "x40",
    "withdrawSpeed": "до 24ч",
    "withdrawLimit": "30 000 ₽/день",
    "verified": false,
    "isNew": false,
    "providers": [
      "Pragmatic Play",
      "Igrosoft",
      "Amatic",
      "Novomatic",
      "NetEnt",
      "Microgaming"
    ],
    "support": "Онлайн-чат 24/7, Email, Телефон",
    "pros": [
      "100 фриспинов",
      "Телефонная поддержка",
      "Быстрые выплаты",
      "Популярные российские слоты"
    ],
    "cons": [
      "Вейджер x40",
      "Устаревший дизайн"
    ]
  }
];
